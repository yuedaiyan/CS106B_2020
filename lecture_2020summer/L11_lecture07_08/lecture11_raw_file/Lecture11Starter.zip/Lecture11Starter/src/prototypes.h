void runHanoiDemo();
void runSequencesDemo();